import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import sympy as sym

np.set_printoptions(
    threshold=np.inf,      # 显示所有元素（不截断）
    linewidth=np.inf,      # 不换行
    # precision=4,           # 精度
    suppress=True,         # 不使用科学计数法
    floatmode='fixed'      # 固定小数点
)

class SymOptControlWithNoConj:
    '''
        x_dim: 状态变量维度
        f0: 目标函数
        f: 不等式约束
        h: 等式约束
        sympy变量需在外部定义
    '''
    def __init__(self, x_dim, f0):
        self.x_dim = x_dim
        self.f0 = f0
        self.x = sym.symbols(f'x0:{x_dim}')  # 使用同名变量相同特性

        # 绕过L直接构建L的一二阶导 - 无约束下L即为f0
        self.dL = sym.zeros(self.x_dim, 1)
        self.d2L = sym.zeros(self.x_dim, self.x_dim)

        x_symbols = [int(str(sym).replace('x', '')) for sym in self.f0.free_symbols if str(sym).startswith('x')]
        for x_idx in x_symbols:
            df0_dxi = sym.diff(self.f0, self.x[x_idx])
            self.dL[x_idx] += df0_dxi
            for xj_idx in range(self.x_dim):
                self.d2L[x_idx, xj_idx] += sym.diff(df0_dxi, self.x[xj_idx])

        # lambdify预编译
        self.f0_lam = sym.lambdify(self.x, self.f0, 'numpy')
        self.dL_lam = sym.lambdify(self.x, self.dL, 'numpy')
        self.d2L_lam = sym.lambdify(self.x, self.d2L, 'numpy')

    def solve(self, x0, tol=1e-6, max_iter=100, method="newton"):
        '''
            x0: 初始点, 需手动选取可行解
        '''
        x = x0
        a = 0.1
        b = 0.6
        x_vals = np.array([x0])
        f0_vals = np.array([self.f0_lam(*x0)])

        for iter in range(max_iter):
            # print(f"iter: {iter}")
            dx = self.dL_lam(*x)
            d2x = self.d2L_lam(*x)

            # del_x为列向量
            if method == "grad":  # 梯度下降法
                del_x = -dx
            elif method == "newton": # 牛顿法
                try:
                    del_x = np.linalg.solve(d2x, -dx)
                except np.linalg.LinAlgError:
                    del_x = -np.linalg.pinv(d2x) @ dx
            else:
                print("method not supported")
                exit(1)

            # 尝试更新
            t = 1
            while True:
                x_new = x + t * del_x.flatten()
                f_new = self.f0_lam(*x_new)
                f_current = self.f0_lam(*x)
                
                # 检查回溯条件
                condition = f_new <= f_current + a * t * (dx.T @ del_x).item()
                
                if condition or t < 1e-12:  # 避免步长过小
                    x = x_new
                    x_vals = np.vstack((x_vals, x))
                    f0_vals = np.append(f0_vals, f_new)
                    break
                else:
                    t *= b  # 回溯
        return x_vals, f0_vals


x_dim = 2
x = sym.symbols(f'x0:{x_dim}')

f0 = sym.exp(x[0] + 3 * x[1] - 0.1) + sym.exp(x[0] - 3 * x[1] - 0.1) + sym.exp(-x[0] - 0.1)
opt = SymOptControlWithNoConj(x_dim, f0)
x_vals, f0_vals_1 = opt.solve([1,1], method="newton", max_iter=50)
x_vals, f0_vals_2 = opt.solve([1,1], method="grad", max_iter=50)

# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# ax.plot(x_vals[:, 0], x_vals[:, 1], f0_vals, "b-o")
# for i in range(len(x_vals)):
#     ax.text(x_vals[i, 0], x_vals[i, 1], f0_vals[i], f'{f0_vals[i]:.3f}', color='black')
# plt.show()

plt.plot(f0_vals_1[:20], "b", label="newton")
plt.plot(f0_vals_2[:20], "r", label="grad")
plt.legend()
plt.show()
