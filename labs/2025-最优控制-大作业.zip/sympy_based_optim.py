import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import sympy as sym

np.set_printoptions(
    threshold=np.inf,      # 显示所有元素（不截断）
    linewidth=np.inf,      # 不换行
    precision=4,           # 精度
    suppress=True,         # 不使用科学计数法
    floatmode='fixed'      # 固定小数点
)

# ==================================求解器==================================

class SymOptControl:
    '''
        x_dim: 状态变量维度
        f0: 目标函数
        f: 不等式约束
        h: 等式约束
        sympy变量需在外部定义
    '''
    def __init__(self, x_dim, f0, f, h):
        self.x_dim = x_dim
        self.f0 = f0
        self.f = f
        self.h = h

        self.x = sym.symbols(f'x0:{x_dim}')  # 使用同名变量相同特性
        self.u = sym.symbols('u')  # 内点法参数

        # 构造拉格朗日函数
        self.l = sym.symbols(f'l0:{len(f)}')
        self.v = sym.symbols(f'v0:{len(h)}')
        # for i in range(len(self.f)):
        #     print(f"f{i} = {self.f[i]}")
        # for i in range(len(self.h)):
        #     print(f"h{i} = {self.h[i]}")
        # self.L = f0 + sum([self.l[i] * self.f[i] for i in range(len(self.f))]) + sum([self.v[i] * self.h[i] for i in range(len(self.h))])
        # self.L = sym.simplify(self.L)

        # lambda 对角阵
        self.Lambda_ = sym.diag(*self.l)

        # 绕过L直接构建L的一二阶导
        self.dL = sym.zeros(self.x_dim, 1)
        self.d2L = sym.zeros(self.x_dim, self.x_dim)
        self.df = sym.zeros(self.x_dim, len(self.f))
        self.dh = sym.zeros(self.x_dim, len(self.h))

        # print(f"{len(self.f)} f, {len(self.h)} h")
        for f_idx in range(len(self.f)):
            if f_idx % 50 == 0:
                # print("calculating df_dxi for f", f_idx)
                pass
            # 获取f中所有x开头sym变量, 仅对相关变量进行求导, 进一步降低计算量
            x_symbols = [int(str(sym).replace('x', '')) for sym in self.f[f_idx].free_symbols if str(sym).startswith('x')]
            for x_idx in x_symbols:
                df_dxi = sym.diff(self.f[f_idx], self.x[x_idx])
                self.dL[x_idx] += self.l[f_idx] * df_dxi
                self.df[x_idx, f_idx] = df_dxi
                for xj_idx in range(self.x_dim):
                    self.d2L[x_idx, xj_idx] += self.l[f_idx] * sym.diff(df_dxi, self.x[xj_idx])
        for h_idx in range(len(self.h)):
            if h_idx % 50 == 0:
                # print("calculating dh_dxi for h", h_idx)
                pass
            x_symbols = [int(str(sym).replace('x', '')) for sym in self.h[h_idx].free_symbols if str(sym).startswith('x')]
            for x_idx in x_symbols:
                dh_dxi = sym.diff(self.h[h_idx], self.x[x_idx])
                self.dL[x_idx] += self.v[h_idx] * dh_dxi
                self.dh[x_idx, h_idx] = dh_dxi
                for xj_idx in range(self.x_dim):
                    d2h_dxixj = sym.diff(dh_dxi, self.x[xj_idx])
                    self.d2L[x_idx, xj_idx] += self.v[h_idx] * d2h_dxixj
        x_symbols = [int(str(sym).replace('x', '')) for sym in self.f0.free_symbols if str(sym).startswith('x')]
        for x_idx in x_symbols:
            df0_dxi = sym.diff(self.f0, self.x[x_idx])
            self.dL[x_idx] += df0_dxi
            for xj_idx in range(self.x_dim):
                self.d2L[x_idx, xj_idx] += sym.diff(df0_dxi, self.x[xj_idx])

        # print("finish constructing dL, d2L")

        # 残差
        self.rd = self.dL  # n维
        self.rh = sym.Matrix([self.h]).transpose()  # p维
        self.rc = self.Lambda_ * sym.Matrix([self.f]).transpose() + sym.matrices.ones(len(self.f), 1) / self.u  # m维

        # 调整维度
        self.df = self.df.transpose()
        self.dh = self.dh.transpose()

        # hessian矩阵, n*n
        self.H = self.d2L

        # lambdify预编译
        self.f_lam = sym.lambdify(self.x, self.f, 'numpy')
        self.h_lam = sym.lambdify(self.x, self.h, 'numpy')
        self.H_lam = sym.lambdify((self.x, self.l, self.v, self.u), self.H, 'numpy')
        self.df_lam = sym.lambdify(self.x, self.df, 'numpy')
        self.dh_lam = sym.lambdify(self.x, self.dh, 'numpy')
        self.rd_lam = sym.lambdify((self.x, self.l, self.v, self.u), self.rd, 'numpy')
        self.rh_lam = sym.lambdify(self.x, self.rh, 'numpy')
        self.rc_lam = sym.lambdify((self.x, self.l, self.u), self.rc, 'numpy')
        self.ldm_lam = sym.lambdify((self.l), self.Lambda_, 'numpy')
        self.f0_lam = sym.lambdify(self.x, self.f0, 'numpy')

        # print("optimization problem ready")

    def solve(self, x0, tol=1e-6, max_iter=100):
        '''
            x0: 初始点, 需手动选取可行解
        '''
        u = 1
        # 构建np向量(x,l,v)
        x = np.array(x0)  # 传入可行解
        l = np.ones(len(self.f))  # >0
        v = np.random.rand(len(self.h))  # 任意
        
        for iter in range(max_iter):
            # print(f"iter {iter}: ")
            # 构建牛顿迭代步
            HL = self.H_lam(x, l, v, u)  # n*n
            # print(self.H)
            # exit(0)
            Df = self.df_lam(*x)  # m*n
            Dh = self.dh_lam(*x)  # p*n
            lDf = np.dot(self.ldm_lam(*l), Df)
            f = np.array(self.f_lam(*x))
            f_diag = np.diag(f)

            N1 = np.concatenate((HL, Df.transpose(), Dh.transpose()), axis=1)
            N2 = np.concatenate((Dh, np.zeros((len(self.h), len(self.h) + len(self.f)))), axis=1)
            N3 = np.concatenate((lDf, f_diag, np.zeros((len(self.f), len(self.h)))), axis=1)  
            NN = np.concatenate((N1, N2, N3), axis=0)
            try:
                inv_N = np.linalg.inv(NN)
            except:
                # print("N is not invertible, try again")
                # 获取非0元素最小值, 作为对角线元素
                NN_not0 = NN[np.nonzero(NN)]
                NN += np.eye(len(NN)) * np.min(np.abs(NN_not0)) * 1e-2
                inv_N = np.linalg.inv(NN)

            rd = self.rd_lam(x, l, v, u)
            rh = self.rh_lam(*x)
            rc = self.rc_lam(x, l, u)
            d = -np.concatenate((rd, rh, rc), axis=0)

            del_z = np.dot(inv_N, d)
            dx = del_z[:len(x)]
            dl = del_z[len(x):len(x) + len(self.f)]
            dv = del_z[len(x) + len(self.f):len(x) + len(self.f) + len(self.h)]

            # 确定初始步长
            # 保证f<0
            ff = -f / np.dot(Df, dx).transpose() * 0.99
            ff = ff[ff > 0]
            step1 = min(ff.min(), 1)
            # 保证l>0
            ll = -l / dl.transpose() * 0.99
            ll = ll[ll > 0]
            step2 = min(ll.min(), 1)
            step = min(step1, step2)

            while True:
                # 尝试更新, 此时输出为行向量
                new_x = x + step * dx.transpose()
                new_l = l + step * dl.transpose()
                new_v = v + step * dv.transpose()
                # 检验约束条件
                if np.all(np.array(self.f_lam(*new_x.transpose())) < 0) and np.all(new_l > 0):
                    break
                else:
                    step *= 0.8

            # 更新
            x = new_x.reshape(-1)
            l = new_l.reshape(-1)
            v = new_v.reshape(-1)

            # 检查终止条件
            gap = -len(self.f) / u  # 对偶间隙
            primal_res = np.linalg.norm(self.h_lam(*x))  # 原问题约束残差
            dual_res = np.linalg.norm(rd)  # 对偶问题约束残差
            # print(f"gap: {gap}, primal_res: {primal_res}, dual_res: {dual_res}")

            if max(gap, primal_res, dual_res) < tol:
                # print(f"finish in {iter} iter, x: {x}, f0: {self.f0_lam(*x)}")
                break
            u = u * 2
        return x

# ==================================示例问题==================================
# x_dim = 2
# x = sym.symbols(f'x0:{x_dim}')

# f0 = 100 * (x[1] - x[0] ** 2) ** 2 + (1 - x[0]) ** 2

# # 不等式约束(包含边界条件) - 定义函数,求解过程中需满足<0, m维
# f = [
#     x[0] + 2 * x[1] - 1,
#     x[0] ** 2 + x[1] - 1,
#     x[0] ** 2 - x[1] - 1,
#     -x[0],
#     x[0] - 1,
#     -0.5 - x[1],
#     x[1] - 2
# ]

# # 等式约束, p维
# h = [
#     2 * x[0] + x[1] - 1,
# ]

# opt = SymOptControl(x_dim, f0, f, h)
# opt.solve([0, 0])
# exit(1)


# ==================================停车问题==================================
# # 定义问题的基本变量
# T0 = 0.0  # 初始时刻
# Tf = 10.0  # 终止时刻
# N = 51  # N-1个时间片段, N个点
# H = (Tf - T0) / (N-1)  # 时间间隔
# LW = 2.8  # 轴距

# # 向量结构: [x(0)...x(N-1), y(0)...y(N-1), v(0)...v(N-1), phi(0)...phi(N-1), theta(0)...theta(N-1), a(0)...a(N-1), omega(0)...omega(N-1)]
# x_dim = 7 * N
# x = sym.symbols(f'x0:{x_dim}')

# # 目标函数
# f0 = sum([x[i] ** 2 for i in range(5 * N, 7 * N)])

# # 状态方程: f(x, u) = [v*cos(theta); v*sin(theta); a; omega; v*tan(phi)/LW]
# phys_iter = []
# for i in range(N):
#     phys_iter.append(sym.Matrix([
#         x[2*N+i] * sym.cos(x[4*N+i]),      # dx/dt = v*cos(theta)
#         x[2*N+i] * sym.sin(x[4*N+i]),      # dy/dt = v*sin(theta)
#         x[5*N+i],                           # dv/dt = a
#         x[6*N+i],                           # dphi/dt = omega
#         x[2*N+i] * sym.tan(x[3*N+i]) / LW   # dtheta/dt = v*tan(phi)/LW
#     ]))

# # 迭代约束: x_{k+1} = x_k + H/2 * [f(x_k, u_k) + f(x_{k+1}, u_{k+1})]
# phys_conj = []
# for k in range(N-1):
#     xk = sym.Matrix([x[k], x[N+k], x[2*N+k], x[3*N+k], x[4*N+k]])
#     xk1 = sym.Matrix([x[k+1], x[N+k+1], x[2*N+k+1], x[3*N+k+1], x[4*N+k+1]])
#     constraint = xk1 - xk - (H/2) * (phys_iter[k] + phys_iter[k+1])
#     phys_conj.append(constraint)

# # 边界条件 - 不等式约束
# bound_conj = []
# for i in range(N):
#     bound_conj.append(-1.0 - x[5*N+i])
#     bound_conj.append(x[5*N+i] - 2.0)
#     bound_conj.append(-0.63792 - x[6*N+i])
#     bound_conj.append(x[6*N+i] - 0.63792)
#     bound_conj.append(-2.0 - x[2*N+i])
#     bound_conj.append(x[2*N+i] - 3.0)
#     bound_conj.append(-0.63792 - x[3*N+i])
#     bound_conj.append(x[3*N+i] - 0.63792)

# # 初/终态条件 - 等式约束
# state_conj = [
#     x[0] - 1.0,
#     x[N] - 8.0,
#     x[2*N] - 0.0,
#     x[3*N] - 0.0,
#     x[4*N] - 0.0,
#     x[N-1] - 9.25,
#     x[2*N-1] - 2.0,
#     x[3*N-1] - 0.0,
#     x[4*N-1] - 0.0,
#     x[5*N-1] - np.pi/2,
#     x[6*N-1] - 0.0,
#     x[7*N-1] - 0.0
# ]

# h = []
# for ph in phys_conj:
#     h.extend(ph)
# h.extend(state_conj)

# f = bound_conj

# opt = SymOptControl(x_dim, f0, f, h)

# # 构建初值
# def create_initial_guess(N):
#     x0 = np.zeros(7*N)
    
#     # 位置：从起点到终点的线性插值
#     x0[0:N] = np.linspace(1.0, 9.25, N)
#     x0[N:2*N] = np.linspace(8.0, 2.0, N)
    
#     # 速度：先加速后减速
#     t = np.linspace(0, 1, N)
#     v_max = 2.0
#     v_profile = 4 * v_max * t * (1 - t)
#     x0[2*N:3*N] = v_profile
    
#     # 航向角：从0到pi/2
#     x0[4*N:5*N] = np.linspace(0, np.pi/2, N)
    
#     # 加速度：根据速度差分计算
#     for k in range(N-1):
#         x0[5*N+k] = (x0[2*N+k+1] - x0[2*N+k]) / H
    
#     # 角速度：根据转角差分计算
#     for k in range(N-1):
#         x0[6*N+k] = (x0[3*N+k+1] - x0[3*N+k]) / H
    
#     # 终端控制设为0
#     x0[5*N+N-1] = 0.0
#     x0[6*N+N-1] = 0.0
    
#     return x0

# # 使用合理初始猜测
# x0_guess = create_initial_guess(N)

# print("\n初始猜测的可行性检查:")
# print(f"初始位置: ({x0_guess[0]:.2f}, {x0_guess[N]:.2f})")
# print(f"终点位置: ({x0_guess[N-1]:.2f}, {x0_guess[2*N-1]:.2f})")
# print(f"初始速度: {x0_guess[2*N]:.2f}")
# print(f"终点速度: {x0_guess[3*N-1]:.2f}")

# # 求解
# x_sol = opt.solve(x0_guess, tol=1e-6, max_iter=100)

# # 整理结果
# result = np.array(x_sol).reshape((-1, N)).transpose()
# print("\n优化结果:")
# print("时间步 |     x    |     y    |     v    |   phi    |  theta   |     a    |   omega  ")
# print("-" * 85)
# for k in range(N):
#     print(f"{k:5d} | {result[k,0]:8.4f} | {result[k,1]:8.4f} | {result[k,2]:8.4f} | "
#           f"{result[k,3]:8.4f} | {result[k,4]:8.4f} | {result[k,5]:8.4f} | {result[k,6]:8.4f}")

# # 可视化
# plt.figure(figsize=(10, 8))

# # 轨迹
# plt.subplot(2, 2, 1)
# plt.plot(x_sol[0:N], x_sol[N:2*N], 'b-o', linewidth=2, markersize=4)
# plt.plot([1, 9.25], [8, 2], 'r--', alpha=0.5)
# plt.xlabel('x [m]')
# plt.ylabel('y [m]')
# plt.title('car trajectory')
# plt.legend()
# plt.grid(True)
# plt.axis('equal')

# # 速度
# plt.subplot(2, 2, 2)
# plt.plot(np.linspace(T0, Tf, N), x_sol[2*N:3*N], 'g-o')
# plt.xlabel('t [s]')
# plt.ylabel('v [m/s]')
# plt.title('v')
# plt.grid(True)

# # 航向角
# plt.subplot(2, 2, 3)
# plt.plot(np.linspace(T0, Tf, N), x_sol[4*N:5*N], 'r-o')
# plt.xlabel('t [s]')
# plt.ylabel('theta [rad]')
# plt.title('theta')
# plt.grid(True)

# # 控制量
# plt.subplot(2, 2, 4)
# plt.plot(np.linspace(T0, Tf, N), x_sol[5*N:6*N], 'c-o', label='a')
# plt.plot(np.linspace(T0, Tf, N), x_sol[6*N:7*N], 'm-o', label='omega')
# plt.xlabel('t [s]')
# plt.ylabel('control value')
# plt.title('input')
# plt.legend()
# plt.grid(True)

# plt.tight_layout()
# plt.show()


# ==================================滚动优化问题==================================

# 记录轨迹
x_traj = np.zeros((1, 7))
x_traj[0, 0] = 1
x_traj[0, 1] = 8

iter = 0
H = 0.2  # 单步时间间隔
LW = 2.8  # 轴距
while True:
    print(f"iter {iter}")
    # 根据当前状态与目标状态距离调整步长
    dist = 3 * (x_traj[-1, 0] - 9.25) ** 2 + 3 * (x_traj[-1, 1] - 2) ** 2 + 3 * (x_traj[-1, 4] - np.pi / 2) ** 2
    N = np.max([np.min([5, int(dist / 2)]), 2])
    print(f"programming {N} steps")

    # 向量结构: [x(0)...x(N-1), y(0)...y(N-1), v(0)...v(N-1), phi(0)...phi(N-1), theta(0)...theta(N-1), a(0)...a(N-1), omega(0)...omega(N-1)]
    x_dim = 7 * N
    x = sym.symbols(f'x0:{x_dim}')

    # 代价函数中 加入状态空间当前值与期望值
    if dist > 2:
        f0 = 0.1 * sum([x[i] ** 2 for i in range(5 * N, 7 * N)]) + 3 * (x[N - 1] - 9.25) ** 2 + 3 * (x[2 * N - 1] - 2) ** 2 + 0.4 * x[3 * N - 1] ** 2 + 3 * (x[5 * N - 1] - np.pi / 2) ** 2
    else:
        f0 = 0.05 * sum([x[i] ** 2 for i in range(5 * N, 7 * N)]) + 4 * (x[N - 1] - 9.25) ** 2 + 4 * (x[2 * N - 1] - 2) ** 2 + 0.2 * x[3 * N - 1] ** 2 + 3 * (x[5 * N - 1] - np.pi / 2) ** 2

    # 状态方程: f(x, u) = [v*cos(theta); v*sin(theta); a; omega; v*tan(phi)/LW]
    phys_iter = []
    for i in range(N):
        phys_iter.append(sym.Matrix([
            x[2*N+i] * sym.cos(x[4*N+i]),      # dx/dt = v*cos(theta)
            x[2*N+i] * sym.sin(x[4*N+i]),      # dy/dt = v*sin(theta)
            x[5*N+i],                           # dv/dt = a
            x[6*N+i],                           # dphi/dt = omega
            x[2*N+i] * sym.tan(x[3*N+i]) / LW   # dtheta/dt = v*tan(phi)/LW
        ]))

    # 迭代约束: x_{k+1} = x_k + H/2 * [f(x_k, u_k) + f(x_{k+1}, u_{k+1})]
    phys_conj = []
    for k in range(N-1):
        xk = sym.Matrix([x[k], x[N+k], x[2*N+k], x[3*N+k], x[4*N+k]])
        xk1 = sym.Matrix([x[k+1], x[N+k+1], x[2*N+k+1], x[3*N+k+1], x[4*N+k+1]])
        constraint = xk1 - xk - (H/2) * (phys_iter[k] + phys_iter[k+1])
        phys_conj.append(constraint)

    # 边界条件 - 不等式约束
    bound_conj = []
    for i in range(N):
        bound_conj.append(-1.0 - x[5*N+i])
        bound_conj.append(x[5*N+i] - 2.0)
        bound_conj.append(-0.63792 - x[6*N+i])
        bound_conj.append(x[6*N+i] - 0.63792)
        bound_conj.append(-2.0 - x[2*N+i])
        bound_conj.append(x[2*N+i] - 3.0)
        bound_conj.append(-0.63792 - x[3*N+i])
        bound_conj.append(x[3*N+i] - 0.63792)
        # bound_conj.append(-(x[i]-9.05) - 1.56 * sym.exp(x[N+i] - 2.938))
        # bound_conj.append((x[i]-9.45) - 1.56 * sym.exp(x[N+i] - 2.938))

    # 初态条件 - 等式约束
    state_conj = [  # 以当前状态开始
        x[0] - x_traj[-1, 0],
        x[N] - x_traj[-1, 1],
        x[2*N] - x_traj[-1, 2],
        x[3*N] - x_traj[-1, 3],
        x[4*N] - x_traj[-1, 4],
    ]

    h = []
    for ph in phys_conj:
        h.extend(ph)
    h.extend(state_conj)

    f = bound_conj

    opt = SymOptControl(x_dim, f0, f, h)

    # 构建初值
    def create_initial_guess(N):
        x0 = np.zeros(7*N)
        
        # 状态空间设为当前值
        x0[0:N] = np.linspace(x_traj[-1, 0], x_traj[-1, 0], N)
        x0[N:2*N] = np.linspace(x_traj[-1, 1], x_traj[-1, 1], N)
        x0[2*N:3*N] = np.linspace(x_traj[-1, 2], x_traj[-1, 2], N)
        x0[3*N:4*N] = np.linspace(x_traj[-1, 3], x_traj[-1, 3], N)
        x0[4*N:5*N] = np.linspace(x_traj[-1, 4], x_traj[-1, 4], N)
        
        return x0

    # 使用合理初始猜测
    x0_guess = create_initial_guess(N)

    # 求解
    x_sol = opt.solve(x0_guess, tol=1e-6, max_iter=100)

    # 整理结果
    result = np.array(x_sol).reshape((-1, N)).transpose()

    # 更新轨迹
    next_step = result[1, :]  # 更新轨迹
    # 添加噪声
    next_step[0] += np.random.normal(0, 0.08)
    next_step[1] += np.random.normal(0, 0.08)
    next_step[2] += np.random.normal(0, 0.04)
    next_step[3] += np.random.normal(0, 0.02)
    next_step[4] += np.random.normal(0, 0.02)
    # 限制边界条件
    next_step[2] = np.clip(next_step[2], -1.99, 2.99)
    next_step[3] = np.clip(next_step[3], -0.6379, 0.6379)
    next_step[4] = np.clip(next_step[4], -0.6379, 0.6379)
    print(f"next step: {next_step}")
    x_traj = np.vstack((x_traj, next_step))

    if iter >= 100 or np.linalg.norm(x_traj[-2, 5:] - x_traj[-1, 5:]) < 1e-6:  # 如果迭代次数超过100次或者当前步与上一步的差值小于1e-3，则停止迭代
        break
    iter += 1
print(x_traj)

# 可视化
plt.figure(figsize=(10, 8))

# 轨迹
plt.subplot(2, 2, 1)
plt.plot(x_traj[:, 0], x_traj[:, 1], 'b-o', linewidth=2, markersize=4)
plt.plot([1, 9.25], [8, 2], 'r--', alpha=0.5)
plt.xlabel('x [m]')
plt.ylabel('y [m]')
plt.title('car trajectory')
plt.legend()
plt.grid(True)
plt.axis('equal')

# 速度
plt.subplot(2, 2, 2)
plt.plot(x_traj[:, 2], 'g-o')
plt.xlabel('iter')
plt.ylabel('v [m/s]')
plt.title('v')
plt.grid(True)

# 航向角
plt.subplot(2, 2, 3)
plt.plot(x_traj[:, 4], 'r-o')
plt.xlabel('iter')
plt.ylabel('theta [rad]')
plt.title('theta')
plt.grid(True)

# 控制量
plt.subplot(2, 2, 4)
plt.plot(x_traj[:, 5], 'c-o', label='a')
plt.plot(x_traj[:, 6], 'm-o', label='omega')
plt.xlabel('iter')
plt.ylabel('control value')
plt.title('input')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()